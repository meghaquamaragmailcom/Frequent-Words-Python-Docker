from flask import Flask
from flask import request
from collections import Counter
app = Flask(__name__)

@app.route("/")
def hello():
	# Read input text files 
	file = open('result.txt')
	file1 = open('result1.txt')
	data_set = file.read()
	data_set1 = file1.read()

	split_result = data_set.split()
	split_result1 = data_set1.split()
	final_result = split_result + split_result1

	# Determination of frequency of words and print 10 most common words globally
	counter1 = Counter(final_result)
	most_common = counter1.most_common(10)

	# Creation of text file to store the final results
	sample_string = ""
	for i in most_common:
		sample_string = sample_string + " " + i[0] + " " + str(i[1]) + "\n"
	file = open("final_result.txt","w")
	file.write(sample_string)
	file.close()

	return sample_string

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80)
