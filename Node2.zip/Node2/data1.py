from collections import Counter
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords

# Read input text file 
text_file = open('data1.txt')
text_file_read = text_file.read()
split_result = text_file_read.lower().split()

# Removal of stop words and delimiters
stop_words = set(stopwords.words('english'))
words_list=[]
for word in split_result:
	word = word.replace("?","")
	word = word.replace(".","")
	word = word.replace(",","")
	word = word.replace("!","")
	if word not in stop_words:
            words_list.append(word)

# Determination of frequency of words and print 10 most common words locally
Counter = Counter(words_list)
most_common = Counter.most_common(10)
print(most_common)

# Creation of text file for the result to be transmitted to central Cloud Server
sample_string = ""
for i in most_common:
	sample_string = sample_string + (i[0] + " ")* i[1]
file = open("result1.txt","w")
file.write(sample_string)
file.close()



